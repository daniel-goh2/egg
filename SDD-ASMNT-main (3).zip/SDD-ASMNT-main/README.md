Binary Puzzle

A simple Sudoku-like game that uses binary digits for solving. Refer to wiki for instruction.