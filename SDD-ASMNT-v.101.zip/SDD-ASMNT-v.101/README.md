# SDD-ASMNT

This project and all renditions, modifications or prototypes including experimental projects, live fire tests and full version attempts are property of Binoids by ATOMICA INDUSTRIES. Any attempts to rebrand modified code or protypes is NOT ALLOWED. By using this code you agree to NOT REBRAND CODE. You are allowed to modify code however you may like and redistibute code BUT THIS README MUST BE INCLUDED.

Group members: Daniel, Finn, Jordan
